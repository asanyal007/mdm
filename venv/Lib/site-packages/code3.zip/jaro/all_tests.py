from . import compare_strcmp95
from . import compare_jaro
from . import jaro_tests

compare_strcmp95.test()
compare_jaro.test()
jaro_tests.test()